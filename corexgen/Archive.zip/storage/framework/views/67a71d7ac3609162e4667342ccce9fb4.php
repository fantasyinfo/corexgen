<?php $__env->startSection('content'); ?>

<div class="col-md-6">
    <div class="card">
        <div class="card-header">
            <h2><?php echo e(__('welcome.Hello_World')); ?></h2>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/gauravsharma/Documents/coreXgen/corexgen/resources/views/dashboard/index.blade.php ENDPATH**/ ?>
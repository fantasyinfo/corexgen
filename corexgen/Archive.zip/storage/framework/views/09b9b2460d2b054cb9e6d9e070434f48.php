<?php
    $menus = getCRMMenus();
?>

<nav class="nxl-navigation">
    <div class="navbar-wrapper">
        <div class="m-header">
            <a href="index.html" class="b-brand">
                <!-- ========   change your logo hear   ============ -->
                <img src="<?php echo e(asset('assets/images/logo-full.png')); ?>" alt="" class="logo logo-lg" />
                <img src="<?php echo e(asset('assets/images/logo-abbr.png')); ?>" alt="" class="logo logo-sm" />
            </a>
        </div>
        <div class="navbar-content">
            <ul class="nxl-navbar">
                <li class="nxl-item nxl-caption">
                    <label>Navigation</label>
                </li>
            
                <?php $__currentLoopData = $menus->where('parent_menu', '1'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $childMenus = $menus->where('parent_menu_id', $parentMenu->id);
                        $hasChildPermission = $childMenus->contains(function ($childMenu) {
                            return hasMenuPermission($childMenu->permission_id);
                        });
                        $hasParentPermission = hasMenuPermission($parentMenu->permission_id);
                    ?>
        
                    <?php if($hasChildPermission || $hasParentPermission): ?>
                    <li>
                        <a href="javascript:void(0);" class="nxl-link">
                            <span class="nxl-micon"><i class="<?php echo e($parentMenu->menu_icon); ?>"></i></span>
                            <span class="nxl-mtext"><?php echo e($parentMenu->menu_name); ?></span>
                            <span class="nxl-arrow"><i class="feather-chevron-right"></i></span>
                        </a>
        
                        <?php if($childMenus->count()): ?>
                            <ul class="nxl-submenu">
                                <?php $__currentLoopData = $childMenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(hasMenuPermission($childMenu->permission_id)): ?>
                                        <li class="nxl-item">
                                            <a class="nxl-link" href="<?php echo e(route($childMenu->menu_url)); ?>"> 
                                                <i class="<?php echo e($childMenu->menu_icon); ?>"></i><?php echo e($childMenu->menu_name); ?>

                                            </a>
                                        </li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</nav><?php /**PATH /Users/gauravsharma/Documents/coreXgen/corexgen/resources/views/layout/header/nav.blade.php ENDPATH**/ ?>
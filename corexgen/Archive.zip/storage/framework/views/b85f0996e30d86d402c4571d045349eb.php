<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="card-title"><?php echo e(__('crm_permissions.Permissions Management')); ?></h5>
            <div class="card-header-action">
                <?php if(hasPermission('PERMISSIONS.CREATE')): ?>
                <a href="<?php echo e(route('crm.permissions.create')); ?>" class="btn btn-md btn-primary me-2">
                    <i class="feather feather-plus"></i> <span><?php echo e(__('crm_permissions.Create Permissions')); ?></span>
                </a>
                <?php endif; ?>
        
            </div>
        </div>

        <div class="card-body">
            <!-- Roles Table -->
            <div class="table-responsive">
                <?php if(hasPermission('PERMISSIONS.READ_ALL') || hasPermission('PERMISSIONS.READ') ): ?>
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>
                                <a href="<?php echo e(request()->fullUrlWithQuery([
                                    'sort' => 'role_name', 
                                    'direction' => request('sort') == 'role_name' && request('direction') == 'asc' ? 'desc' : 'asc'
                                ])); ?>">
                                    <?php echo e(__('crm_permissions.Role Name')); ?>

                                    <?php if(request('sort') == 'role_name'): ?>
                                        <?php echo request('direction') == 'asc' ? '&#9650;' : '&#9660;'; ?>

                                    <?php endif; ?>
                                </a>
                            </th>
              
                           
                         
                   
                            <th class="text-end"><?php echo e(__('crud.Actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($role->role_name); ?></td>
                                <?php if(hasPermission('PERMISSIONS.UPDATE') || hasPermission('PERMISSIONS.DELETE')): ?>
                                <td class="text-end">
                                 

                                    <div class="dropdown">
                                        <a href="javascript:void(0)" class="avatar-text avatar-md ms-auto" data-bs-toggle="dropdown" data-bs-offset="0,28" aria-expanded="false">
                                            <i class="feather feather-more-horizontal"></i>
                                        </a>
                                        <ul class="dropdown-menu" style="">
                                            <?php if(hasPermission('PERMISSIONS.UPDATE')): ?>
                                            <li>
                                                <a class="dropdown-item" href="<?php echo e(route('crm.permissions.edit',['id' => $role->id] )); ?>">
                                                    <i class="feather feather-edit-3 me-3"></i>
                                                    <span><?php echo e(__('crud.Edit')); ?></span>
                                                </a>
                                            </li>
                                            <?php endif; ?>
                                            <?php if(hasPermission('PERMISSIONS.DELETE')): ?>
                                            <li class="dropdown-divider"></li>
                                            <li>
                                                <form action="<?php echo e(route('crm.permissions.destroy', ['id' => $role->id])); ?>" method="POST" 
                                                onsubmit="return confirm('<?php echo e(__('crud.Are you sure?')); ?>');">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="dropdown-item text-danger">
                                                        <i class="feather feather-trash-2 me-2"></i><?php echo e(__('crud.Delete')); ?>

                                                    </button>
                                                </form>
                                               
                                            </li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                </td>
                                <?php else: ?>
                                <td class="text-end">...</td>
                                <?php endif; ?>
                               
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center"><i class="fa-solid fa-file"></i> <?php echo e(__('crm_permissions.No Permissions Found')); ?></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <?php else: ?> 
                <table class="table table-hover">
                    <tbody>
                            <tr>
                                <td colspan="5" class="text-center"><i class="fa-solid fa-file"></i> <?php echo e(__('crud.You do not have permission to view the table')); ?></td>
                            </tr>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>

            <?php if(hasPermission('PERMISSIONS.READ_ALL') || hasPermission('PERMISSIONS.READ') ): ?>
            <!-- Pagination -->
            <div class="d-flex justify-content-between align-items-center mt-3">
                <div>
                    <?php echo e(__('crud.Showing')); ?> <?php echo e($permissions->firstItem()); ?> - <?php echo e($permissions->lastItem()); ?> 
                    <?php echo e(__('crud.of')); ?> <?php echo e($permissions->total()); ?> <?php echo e(__('crud.results')); ?>

                </div>
                <?php echo e($permissions->links('layout.components.pagination')); ?>

            </div>
            <?php endif; ?>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/gauravsharma/Documents/coreXgen/corexgen/resources/views/dashboard/crm/permissions/index.blade.php ENDPATH**/ ?>
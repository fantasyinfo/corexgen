<?php echo e($slot); ?>

<?php /**PATH /Users/gauravsharma/Documents/coreXgen/corexgen/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>
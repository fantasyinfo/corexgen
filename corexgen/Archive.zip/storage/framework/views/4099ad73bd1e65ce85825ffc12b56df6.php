<?php if($paginator->hasPages()): ?>
    <div class="card-footer">
        <ul class="list-unstyled d-flex align-items-center gap-2 mb-0 pagination-common-style">
            
            <?php if($paginator->onFirstPage()): ?>
                <li>
                    <span><i class="bi bi-arrow-left"></i></span>
                </li>
            <?php else: ?>
                <li>
                    <a href="<?php echo e($paginator->previousPageUrl()); ?>"><i class="bi bi-arrow-left"></i></a>
                </li>
            <?php endif; ?>

            
            <?php
                $currentPage = $paginator->currentPage();
                $lastPage = $paginator->lastPage(); 
                
                // Calculate start and end for main pagination range
                $start = max(1, $currentPage - 3);
                $end = min($lastPage, $currentPage + 3);
            ?>

            
            <?php if($start > 1): ?>
                <li>
                    <a href="<?php echo e($paginator->url(1)); ?>">1</a>
                </li>
                <?php if($start > 2): ?>
                    <li>
                        <span><i class="bi bi-dot"></i></span>
                    </li>
                <?php endif; ?>
            <?php endif; ?>

            
            <?php for($page = $start; $page <= $end; $page++): ?>
                <?php if($page == $currentPage): ?>
                    <li>
                        <a href="javascript:void(0);" class="active"><?php echo e($page); ?></a>
                    </li>
                <?php else: ?>
                    <li>
                        <a href="<?php echo e($paginator->url($page)); ?>"><?php echo e($page); ?></a>
                    </li>
                <?php endif; ?>
            <?php endfor; ?>

            
            <?php if($end < $lastPage): ?>
                <?php if($end < $lastPage - 1): ?>
                    <li>
                        <span><i class="bi bi-dot"></i></span>
                    </li>
                <?php endif; ?>
                <li>
                    <a href="<?php echo e($paginator->url($lastPage)); ?>"><?php echo e($lastPage); ?></a>
                </li>
            <?php endif; ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li>
                    <a href="<?php echo e($paginator->nextPageUrl()); ?>"><i class="bi bi-arrow-right"></i></a>
                </li>
            <?php else: ?>
                <li>
                    <span><i class="bi bi-arrow-right"></i></span>
                </li>
            <?php endif; ?>
        </ul>
    </div>
<?php endif; ?><?php /**PATH /Users/gauravsharma/Documents/coreXgen/corexgen/resources/views/layout/components/pagination.blade.php ENDPATH**/ ?>
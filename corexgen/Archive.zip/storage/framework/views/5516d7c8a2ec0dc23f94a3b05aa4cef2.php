<div class="page-header">
    <div class="page-header-left d-flex align-items-center">
        <div class="page-header-title">
            <h5 class="m-b-10"><?php echo e(__('navbar.Dashboard')); ?></h5>
        </div>
        <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.html"><?php echo e(__('navbar.Home')); ?></a></li>
            <li class="breadcrumb-item"><?php echo e($title ? $title : ''); ?></li>
        </ul>
    </div>
    
</div><?php /**PATH /Users/gauravsharma/Documents/coreXgen/corexgen/resources/views/layout/header/page.blade.php ENDPATH**/ ?>
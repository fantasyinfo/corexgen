<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale') || 'en'); ?>">


<?php echo $__env->make('layout.header.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
    body.modal-open .nxl-container{
        filter:none !important;
    }
</style>
<body>


<?php echo $__env->make('layout.header.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('layout.header.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="nxl-container">

<?php /**PATH /Users/gauravsharma/Documents/coreXgen/corexgen/resources/views/layout/header/header.blade.php ENDPATH**/ ?>
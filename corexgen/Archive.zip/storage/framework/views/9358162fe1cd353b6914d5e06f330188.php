<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="card-title"><?php echo e(__('crm_role.Roles Management')); ?></h5>
            <div class="card-header-action">
                <?php if(hasPermission('ROLE.CREATE')): ?>
                <a href="<?php echo e(route('crm.role.create')); ?>" class="btn btn-md btn-primary me-2">
                    <i class="feather feather-plus"></i> <span><?php echo e(__('crm_role.Create Role')); ?></span>
                </a>
                <?php endif; ?>
                <?php if(hasPermission('ROLE.EXPORT')): ?>
                <a href="<?php echo e(route('crm.role.export', request()->all())); ?>" class="btn btn-md btn-outline-secondary">
                    <i class="feather feather-download"></i> <span><?php echo e(__('crud.Export')); ?></span>
                </a>
                <?php endif; ?>
                <?php if(hasPermission('ROLE.IMPORT')): ?>
                <button data-bs-toggle="modal" data-bs-target="#bulkImportModal" class="btn btn-md btn-outline-info">
                    <i class="feather feather-upload"></i><span> <?php echo e(__('crud.Import')); ?></span>
                </button>
                <?php endif; ?>
                <?php if(hasPermission('ROLE.FILTER')): ?>
                <button onclick="openFilters()" class="btn btn-md btn-light-brand">
                    <i class="feather-filter me-2"></i>
                    <span><?php echo e(__('crud.Filter')); ?></span>
                </button>
                <?php endif; ?>
            </div>
        </div>

        <div class="card-body">
     
               
            <?php if(hasPermission('ROLE.FILTER')): ?>
            <div id="filter-section">
                <!-- Advanced Filter Form -->
                <form action="<?php echo e(route('crm.role.index')); ?>" method="GET" class="mb-4">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <input type="text" name="name" class="form-control" 
                                placeholder="<?php echo e(__('crm_role.Role Name')); ?>" 
                                value="<?php echo e(request('name')); ?>">
                        </div>
                        <div class="col-md-2">
                            <select name="status" class="form-select">
                                <option value=""><?php echo e(__('crm_role.All Statuses')); ?></option>
                                <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>
                                    <?php echo e(__('Active')); ?>

                                </option>
                                <option value="deactive" <?php echo e(request('status') == 'inactive' ? 'selected' : ''); ?>>
                                    <?php echo e(__('Inactive')); ?>

                                </option>
                            </select>
                        </div>
                        <div class="col-md-1">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="feather feather-search"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            <?php endif; ?>

            <!-- Roles Table -->
            <div class="table-responsive">
                <?php if(hasPermission('ROLE.READ_ALL') || hasPermission('ROLE.READ') ): ?>
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>
                                <a href="<?php echo e(request()->fullUrlWithQuery([
                                    'sort' => 'role_name', 
                                    'direction' => request('sort') == 'role_name' && request('direction') == 'asc' ? 'desc' : 'asc'
                                ])); ?>">
                                    <?php echo e(__('crm_role.Role Name')); ?>

                                    <?php if(request('sort') == 'role_name'): ?>
                                        <?php echo request('direction') == 'asc' ? '&#9650;' : '&#9660;'; ?>

                                    <?php endif; ?>
                                </a>
                            </th>
                            <th><?php echo e(__('crm_role.Description')); ?></th>
                            <th><?php echo e(__('crud.Status')); ?></th>
                            <th><?php echo e(__('crud.Created At')); ?></th>
                   
                            <th class="text-end"><?php echo e(__('crud.Actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($role->role_name); ?></td>
                                <td><?php echo e(Str::limit($role->role_desc, 50)); ?></td>
                                <td>
                                    <a href="<?php echo e(route('crm.role.changeStatus',['id' => $role->id] )); ?>">
                                        <span class="badge <?php echo e($role->status == 'active' ? 'bg-success' : 'bg-danger'); ?>">
                                            <?php echo e(ucfirst($role->status)); ?>

                                        </span>
                                    </a>
                                </td>
                                <td><?php echo e($role->created_at->format('d M Y')); ?></td>
                                <?php if(hasPermission('ROLE.UPDATE') || hasPermission('ROLE.DELETE')): ?>
                                <td class="text-end">
                                 

                                    <div class="dropdown">
                                        <a href="javascript:void(0)" class="avatar-text avatar-md ms-auto" data-bs-toggle="dropdown" data-bs-offset="0,28" aria-expanded="false">
                                            <i class="feather feather-more-horizontal"></i>
                                        </a>
                                        <ul class="dropdown-menu" style="">
                                            <?php if(hasPermission('ROLE.UPDATE')): ?>
                                            <li>
                                                <a class="dropdown-item" href="<?php echo e(route('crm.role.edit',['id' => $role->id] )); ?>">
                                                    <i class="feather feather-edit-3 me-3"></i>
                                                    <span><?php echo e(__('crud.Edit')); ?></span>
                                                </a>
                                            </li>
                                            <?php endif; ?>
                                            <?php if(hasPermission('ROLE.DELETE')): ?>
                                            <li class="dropdown-divider"></li>
                                            <li>
                                                <form action="<?php echo e(route('crm.role.destroy', ['id' => $role->id])); ?>" method="POST" 
                                                onsubmit="return confirm('<?php echo e(__('crud.Are you sure?')); ?>');">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="dropdown-item text-danger">
                                                        <i class="feather feather-trash-2 me-2"></i><?php echo e(__('crud.Delete')); ?>

                                                    </button>
                                                </form>
                                               
                                            </li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                </td>
                                <?php else: ?>
                                <td class="text-end">...</td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center"><i class="fa-solid fa-file"></i> <?php echo e(__('crm_role.No Roles Found.')); ?></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <?php else: ?> 
                <table class="table table-hover">
                    <tbody>
                            <tr>
                                <td colspan="5" class="text-center"><i class="fa-solid fa-file"></i> <?php echo e(__('crud.You do not have permission to view the table')); ?></td>
                            </tr>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>

            <?php if(hasPermission('USERS.READ_ALL') || hasPermission('USERS.READ') ): ?>
            <!-- Pagination -->
            <div class="d-flex justify-content-between align-items-center mt-3">
                <div>
                    <?php echo e(__('crud.Showing')); ?> <?php echo e($roles->firstItem()); ?> - <?php echo e($roles->lastItem()); ?> 
                    <?php echo e(__('crud.of')); ?> <?php echo e($roles->total()); ?> <?php echo e(__('crud.results')); ?>

                </div>
                <?php echo e($roles->links('layout.components.pagination')); ?>

            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="bulkImportModal" tabindex="-1">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <form id="bulkImportForm" enctype="multipart/form-data">
                <div class="modal-header">
                    <h5 class="modal-title" id="bulkImportModalLabel">Bulk Import Roles</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="csvFile" class="form-label">Upload CSV File</label>
                        <div class="drop-zone" style="border: 2px dashed #ddd; padding: 20px; text-align: center;">
                            <input type="file" name="file" id="csvFile" class="form-control" accept=".csv" style="display: none;" />
                            <p>Drag & Drop your file here or click to browse</p>
                        </div>
                        <small class="form-text text-muted">Only CSV files are allowed. Max size: 2MB</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Import</button>
                </div>
            </form>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>


<?php $__env->startPush('style'); ?>
<style>
    #filter-section{
        display:none;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>

function openFilters() {
    const filterSection = document.getElementById('filter-section');
    if (filterSection.style.display === 'block') {
        filterSection.style.display = 'none';
    } else {
        filterSection.style.display = 'block';
    }
}

document.querySelector('.drop-zone').addEventListener('click', function () {
        document.querySelector('#csvFile').click();
    });

    document.querySelector('#csvFile').addEventListener('change', function () {
        const file = this.files[0];
        if (file) {
            this.nextElementSibling.textContent = file.name;
        }
    });

    document.querySelector('#bulkImportForm').addEventListener('submit', async function (e) {
        e.preventDefault();

        const formData = new FormData(this);
        const response = await fetch('<?php echo e(route('crm.role.import')); ?>', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            body: formData
        });

        const result = await response.json();
        if (result.success) {
            alert(result.message);
            location.reload();
        } else {
            alert(result.message || 'Import failed. Please check the file format.');
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/gauravsharma/Documents/coreXgen/corexgen/resources/views/dashboard/crm/role/index.blade.php ENDPATH**/ ?>

    <?php echo $__env->make('layout.header.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   

        <div class="nxl-content">
         
       
            <?php echo $__env->make('layout.header.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="main-content">
              <div class="row">
                <?php echo $__env->make('layout.components.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
              </div>
            </div>
       
        </div>

 <?php echo $__env->make('layout.footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/gauravsharma/Documents/coreXgen/corexgen/resources/views/layout/app.blade.php ENDPATH**/ ?>
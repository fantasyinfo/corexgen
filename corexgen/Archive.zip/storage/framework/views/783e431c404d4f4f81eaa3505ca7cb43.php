<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/gauravsharma/Documents/coreXgen/corexgen/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>
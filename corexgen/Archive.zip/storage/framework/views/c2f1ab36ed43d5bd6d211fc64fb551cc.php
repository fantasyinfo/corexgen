<a href="<?php echo e(route('crm.role.index')); ?>">Visit CRM </a>

<form method="POST" action="<?php echo e(route('logout')); ?>">
    <?php echo csrf_field(); ?>
    <button type="submit" class="btn btn-danger">Logout</button>
</form><?php /**PATH /Users/gauravsharma/Documents/coreXgen/corexgen/resources/views/welcome.blade.php ENDPATH**/ ?>
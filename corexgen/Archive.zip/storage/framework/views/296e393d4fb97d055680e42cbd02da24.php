<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="card stretch stretch-full">
                <form id="roleForm" action="<?php echo e(route('crm.permissions.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="card-body general-info">
                        <div class="mb-5 d-flex align-items-center justify-content-between">
                            <h5 class="fw-bold mb-0 me-4">
                                <span class="d-block mb-2"><?php echo e(__('crm_permissions.Create New Permissions')); ?></span>
                                <span class="fs-12 fw-normal text-muted text-truncate-1-line"><?php echo e(__('crud.Please add correct information')); ?></span>
                            </h5>
                            <button type="submit" class="btn btn-primary">
                                <i class="feather-plus me-2"></i> <span><?php echo e(__('crm_permissions.Create Permissions')); ?></span>
                            </button>
                        </div>

                          <!-- Role Selection Field -->
                          <div class="row mb-4 align-items-center">
                            <div class="col-lg-4">
                                <label for="role_id" class="fw-semibold"><?php echo e(__('crm_permissions.Select Role')); ?>: <span class="text-danger">*</span></label>
                            </div>
                            <div class="col-lg-8">
                                <div class="input-group">
                                    <div class="input-group-text"><i class="fa-regular fa-user"></i></div>
                                    <select class="form-control select2-hidden-accessible <?php $__errorArgs = ['role_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="role_id" id="role_id">
                                        <?php if($roles && $roles->isNotEmpty()): ?>
                                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($role->id); ?>" <?php echo e(old('role_id') == $role->id ? 'selected' : ''); ?>>
                                                    <?php echo e($role->role_name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <option disabled>No roles available</option>
                                        <?php endif; ?>
                                    </select>
                                    <div class="invalid-feedback" id="role_idError">
                                        <?php $__errorArgs = ['role_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                            <!-- Role Selection Field -->
                            <div class="row mb-4 align-items-center">
                                <div class="col-lg-12">
                                    <div class="row">

                                    
                                    <?php $__currentLoopData = $crm_permissions->where('parent_menu', '1'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4 mt-5">

                                   
                                    <div class="form-check mb-2">
                                        <input 
                                            type='checkbox' 
                                            class='form-check-input parent-checkbox' 
                                            id='parent_<?php echo e($parentMenu->permission_id); ?>' 
                                            name='permissions[]'
                                            value='<?php echo e($parentMenu->permission_id); ?>'
                                        />
                                        <label class="form-check-label" for='parent_<?php echo e($parentMenu->id); ?>'>
                                            <?php echo e($parentMenu->name); ?>

                                        </label>
                                        
                                        <?php if($crm_permissions->where('parent_menu_id', $parentMenu->id)->count()): ?>
                                            <ul class="nxl-submenu mt-3">
                                                <?php $__currentLoopData = $crm_permissions->where('parent_menu_id', $parentMenu->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li class="nxl-item form-check">
                                                        <input 
                                                            type='checkbox' 
                                                            class='form-check-input child-checkbox child_<?php echo e($parentMenu->permission_id); ?>' 
                                                            id='child_<?php echo e($childMenu->permission_id); ?>'
                                                            name='permissions[]'
                                                            value='<?php echo e($childMenu->permission_id); ?>'
                                                        />
                                                        <label class="form-check-label" for='child_<?php echo e($childMenu->id); ?>'>
                                                            <?php echo e($childMenu->name); ?>

                                                        </label>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                                </div>
                            </div>
                     
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
    <?php $__env->stopSection(); ?>

        
    <?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Parent checkbox click handler
            const parentCheckboxes = document.querySelectorAll('.parent-checkbox');
            parentCheckboxes.forEach(parentCheckbox => {
                parentCheckbox.addEventListener('change', function() {
                    const parentId = this.id.replace('parent_', '');
                    const childCheckboxes = document.querySelectorAll(`.child_${parentId}`);
                    
                    childCheckboxes.forEach(childCheckbox => {
                        childCheckbox.checked = this.checked;
                    });
                });
            });
        
            // Child checkbox click handler
            const childCheckboxes = document.querySelectorAll('.child-checkbox');
            childCheckboxes.forEach(childCheckbox => {
                childCheckbox.addEventListener('change', function() {
                    const parentId = this.classList[2].replace('child_', '');
                    const parentCheckbox = document.getElementById(`parent_${parentId}`);
                    const allChildCheckboxes = document.querySelectorAll(`.child_${parentId}`);
                    
                    // Check if all child checkboxes are checked
                    const allChildChecked = Array.from(allChildCheckboxes).every(cb => cb.checked);
                    parentCheckbox.checked = allChildChecked;
                });
            });
        });
        </script>
    <?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/gauravsharma/Documents/coreXgen/corexgen/resources/views/dashboard/crm/permissions/create.blade.php ENDPATH**/ ?>
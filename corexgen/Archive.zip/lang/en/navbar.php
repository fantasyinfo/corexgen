<?php 

return  [
    'Navigation' => 'Navigation',
    'Home' => 'Home',
    'Dashboard' => 'Dashboard',
    'Role' => 'Role',

];
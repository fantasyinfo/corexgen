<?php 

return [

    'Permissions'=> "Permissions",
    'Permissions Management' => 'Permissions Management',
    'Create Permissions' => 'Create Permissions',
    'Permissions Name' => 'Permissions Name',
    'All Statuses' => 'All Statuses',
    'Description' => 'Description',
    'Create New Permissions' => 'Create New Permissions',
    'Update Permissions' => 'Update Permissions',
    'No Permissions Found' => 'No Permissions Found',
    'Select Role' => 'Select Role',
    'Role Name' => 'Role Name'


];
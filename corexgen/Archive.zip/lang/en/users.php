<?php 

return [

    'Users'=> "Users",
    'Users Management' => 'Users Management',
    'Create User' => 'Create User',
    'Name' => 'Name',
    'Email' => 'Email',
    'Role' => 'Role',
    'All Statuses' => 'All Statuses',
    'Select Role' => 'Select Role',
    'Description' => 'Description',
    'Create New User' => 'Create New User',
    'Update User' => 'Update User',
    'Password' => 'Password',
    'Full Name' => 'Full Name',
    'No Users Found' => 'No Users Found'


];
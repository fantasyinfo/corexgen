<?php 

return [

    'Role'=> "Role",
    'Roles Management' => 'Roles Management',
    'Create Role' => 'Create Role',
    'Role Name' => 'Role Name',
    'All Statuses' => 'All Statuses',
    'Description' => 'Description',
    'Create New Role' => 'Create New role',
    'Update Role' => 'Update Role',
    'No Roles Found' => 'No Roles Found'


];
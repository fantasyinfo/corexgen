<?php 

return  [
    'Navigation' => 'मार्गदर्शन',
    'Home' => 'घर',
    'Dashboard' => 'डैशबोर्ड',
];
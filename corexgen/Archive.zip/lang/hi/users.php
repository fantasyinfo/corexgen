<?php 

return [

    'Users'=> "उपयोगकर्ता",
    'Users Management' => 'उपयोगकर्ता प्रबंधन',
    'Create User' => 'उपयोगकर्ता बनाएं',
    'Name' => 'नाम',
    'Email' => 'ईमेल',
    'Role' => 'भूमिका',
    'All Statuses' => 'सभी स्थितियां',
    'Select Role' => 'भूमिका चुनें',
    'Description' => 'विवरण',
    'Create New User' => 'नया उपयोगकर्ता बनाएं',
    'Update User' => 'उपयोगकर्ता अपडेट करें',
    'Password' => 'पासवर्ड',
    'Full Name' => 'पूरा नाम'

];
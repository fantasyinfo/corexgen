<?php 

return  [
    'Hello_World' => 'हैलो वर्ल्ड'
];
<?php

return [
    'Create' => 'बनाएं',
    'Read' => 'पढ़ें',
    'Update' => 'अपडेट करें',
    'Delete' => 'हटाएं',
    'Select' => 'चुनें',
    'SelectAll' => 'सभी चुनें',
    'DeleteAll' => 'सभी हटाएं',
    'Search' => 'खोजें',
    'Form' => 'फॉर्म',
    'Submit' => 'जमा करें',
    'Export' => 'निर्यात करें',
    'Import' => 'आयात करें',
    'Filter' => 'फ़िल्टर',
    'Status' => 'स्थिति',
    'Created At' => 'बनाया गया',
    'Actions' => 'क्रियाएं',
    'Edit' => 'संपादित करें',
    'Are you sure?' => 'क्या आप निश्चित हैं?',
    'Please add correct information' => 'कृपया सही जानकारी जोड़ें',
    "Showing" => 'दिखा रहा है',
    'of' => 'का',
    'results' => 'परिणाम'
];
<?php 

return [

    'Role' => "भूमिका",
    'Roles Management' => 'भूमिका प्रबंधन',
    'Create Role' => 'भूमिका बनाएं',
    'Role Name' => 'भूमिका नाम',
    'All Statuses' => 'सभी स्थिति',
    'Description' => 'विवरण',
    'Create New Role' => 'नई भूमिका बनाएं',
    'Update Role' => 'भूमिका अपडेट करें'

];
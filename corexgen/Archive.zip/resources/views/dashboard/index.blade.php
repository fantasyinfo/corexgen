@extends('layout.app')

@section('content')

<div class="col-md-6">
    <div class="card">
        <div class="card-header">
            <h2>{{__('welcome.Hello_World')}}</h2>
        </div>
    </div>
</div>
@endsection